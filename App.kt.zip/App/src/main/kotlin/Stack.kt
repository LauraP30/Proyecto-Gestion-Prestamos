class Stack <T> {

    companion object {
        val items = mutableListOf<Any>()
        val prestamoStack = Stack<Prestamo>()

        fun <T> obtenerItems(): List<T> {
            return items as List<T>
        }

        fun <T> obtenerPrestamoStack(): Stack<T> {
            return Stack()
        }

    }
        fun push(item: T) {
            items.add(item as Any)
        }

        fun pop(): T? {
            if (isEmpty()) return null
            val lastIndex = items.size - 1
            val item = items[lastIndex] as T
            items.removeAt(lastIndex)
            return item
        }

        fun isEmpty(): Boolean {
            return items.isEmpty()
        }

        fun peek(): T? {
            if (isEmpty()) return null
            val lastIndex = items.size - 1
            return items[lastIndex] as T
    }
}