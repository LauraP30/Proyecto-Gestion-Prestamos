

import java.text.SimpleDateFormat
import java.util.*

data class Prestamo(
    val nombreD: String,
    val correoD: String,
    val numeroD: String,
    val direccion: String,
    val cantidad: Double,
    val fecha: String,
    val cuotas: Int,
    val tipo: String,
    val estado: String
) {

    fun obtenerEstadoActual(): String {
        val fechaActual = SimpleDateFormat("yyyy-MM-dd").format(Date())
        val proximaFechaPago = calcularProximaFechaPago(fecha, tipo)

        return when {
            fechaActual < fecha -> "Por Pagar"
            fechaActual <= SimpleDateFormat("yyyy-MM-dd").format(proximaFechaPago) -> "Por Pagar"
            fechaActual <= calcularFechaVencimiento(fecha, 6) -> "Vencido"
            else -> "Reportado"
        }
    }

    companion object {
        val prestamos = mutableListOf<Prestamo>()
        val prestamosPorPagar: Queue<Prestamo> = LinkedList()

        fun solicitarPrestamo() {
            println("Estás registrando un préstamo.")
            println("Ingrese el nombre del Deudor: ")
            val nombreD = readLine().orEmpty()
            println("Ingrese el correo: ")
            val correoD = readLine().orEmpty()
            println("Ingrese el número de contacto: ")
            val numeroD = readLine().orEmpty()
            println("Ingrese su dirección: ")
            val direccion = readLine().orEmpty()
            println("Ingrese la cantidad del préstamo: ")
            val cantidad = readLine()?.toDoubleOrNull() ?: 0.0
            val fecha = SimpleDateFormat("yyyy-MM-dd").format(Date())
            println("Ingrese la cantidad de cuotas: ")
            val cuotas = readLine()?.toIntOrNull() ?: 0
            println("Tipo de Cuota")
            val tipo = "Mensual"
            val nuevoPrestamo = Prestamo(nombreD, correoD,
                    numeroD, direccion, cantidad, fecha, cuotas, tipo, "Por Pagar")
            prestamos.add(nuevoPrestamo)
            prestamosPorPagar.offer(nuevoPrestamo)
            println("Préstamo agregado con éxito.")
        }

        fun calcularPorcentajeInteres(montoPrestamo: Double, cuotas: Int): Double {
            val tasaInteresBase = 0.05
            val porcentajeInteres = tasaInteresBase * cuotas * montoPrestamo
            return porcentajeInteres
        }

        private fun calcularProximaFechaPago(fechaActual: String, tipoCuota: String): Date {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd")
            val fecha = dateFormat.parse(fechaActual)
            val calendar = Calendar.getInstance()
            calendar.time = fecha
            when (tipoCuota.toLowerCase()) {
                "mensual" -> calendar.add(Calendar.MONTH, 1)
                "quincenal" -> calendar.add(Calendar.DAY_OF_MONTH, 15)
                "anual" -> calendar.add(Calendar.YEAR, 1)
            }
            return calendar.time
        }

        private fun calcularFechaVencimiento(fechaActual: String, meses: Int): String {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd")
            val fecha = dateFormat.parse(fechaActual)
            val calendar = Calendar.getInstance()
            calendar.time = fecha
            calendar.add(Calendar.MONTH, meses)
            return dateFormat.format(calendar.time)
        }

        fun mostrarPrestamos() {
            if (prestamos.isNotEmpty()) {
                println("Préstamos registrados:")
                for ((index, prestamo) in prestamos.withIndex()) {
                    println("Préstamo ${index + 1}:")
                    println("Nombre del Deudor: ${prestamo.nombreD}")
                    println("Correo del Deudor: ${prestamo.correoD}")
                    println("Número de contacto del Deudor: ${prestamo.numeroD}")
                    println("Dirección: ${prestamo.direccion}")
                    println("Cantidad: ${prestamo.cantidad}")
                    println("Fecha: ${prestamo.fecha}")
                    println("Cuotas: ${prestamo.cuotas}")
                    println("Tipo: ${prestamo.tipo}")
                    val interes = calcularPorcentajeInteres(prestamo.cantidad, prestamo.cuotas)
                    val totalPagar = prestamo.cantidad + interes
                    val montoCuota = totalPagar / prestamo.cuotas
                    val proximaFechaPago = calcularProximaFechaPago(prestamo.fecha, prestamo.tipo)
                    println("Interés: $interes")
                    println("Total a pagar: $totalPagar")
                    println("Monto a pagar por cuota: $montoCuota")
                    println("Próxima fecha de pago: ${SimpleDateFormat("yyyy-MM-dd")
                            .format(proximaFechaPago)}")
                }
            } else {
                println("No hay préstamos registrados.")
            }
        }
    }
}