import Usuario.Companion.registroUser


fun main() {
    while (true) {
        println("Seleccione una opción:")
        println("1. Iniciar Sesión")
        println("2. Crear Cuenta")
        println("3. Salir")

        when (readLine()?.toIntOrNull()) {
            1 -> {
                println("Ingrese su correo electrónico: ")
                val email = readLine().orEmpty()
                println("Ingrese su contraseña: ")
                val password = readLine().orEmpty()
                val user = Usuario.inicioSesion(email,password)
                if (user != null) {
                    println("Inicio de sesión exitoso")
                    while (true) {
                        println("Seleccione una opción:")
                        println("1. Préstamo")
                        println("2. Gráficas")
                        println("3. Configuración")
                        println("4. Preguntas")
                        println("5. Cerrar Sesión")

                        when (readLine()?.toIntOrNull()) {
                            1 -> {
                                while (true) {
                                    println("Seleccione una opción:")
                                    println("1. Registrar Préstamo")
                                    println("2. Ver Préstamos")
                                    println("3. Regresar al menú principal")

                                    when (readLine()?.toIntOrNull()) {
                                        1 -> {
                                            Prestamo.solicitarPrestamo()
                                        }
                                        2 -> {
                                            Prestamo.mostrarPrestamos()
                                        }
                                        3 -> break
                                        else -> println("Opción no válida. Intente de nuevo.")
                                    }
                                }
                            }
                            2 -> {
                                println("Opción de gráficas seleccionada.")
                            }
                            3 -> {
                                while (true){
                                    println("Seleccione una opción:")
                                    println("1. Editar Datos")
                                    println("2. Cerrar Sesión")
                                    println("3. Eliminar Cuenta")
                                    println("4. Regresar al menú principal")

                                    when (readLine()?.toIntOrNull()) {
                                        1 -> {
                                            Usuario.editarUsuarioExistente()
                                        }
                                        2 -> {
                                            println("Cerrando sesión")
                                            break
                                        }
                                        3 -> {
                                            println("Ingrese el correo de la cuenta a eliminar:")
                                            val emailAEliminar = readLine() ?: ""

                                            Usuario.eliminarCuenta(emailAEliminar)
                                        }
                                        4 -> break
                                        else -> println("Opción no válida. Intente de nuevo.")
                                    }
                                }
                            }
                            4 -> {
                                while (true) {
                                    println("Seleccione una opción:")
                                    println("1. Realizar Pregunta")
                                    println("2. Ver Preguntas")
                                    println("3. Regresar al menú principal")

                                    when (readLine()?.toIntOrNull()) {
                                        1 -> {
                                            Foro.hacerPregunta()
                                        }
                                        2 -> {
                                            Foro.verPreguntas()
                                        }
                                        3 -> break
                                        else -> println("Opción no válida. Intente de nuevo.")
                                    }
                                }
                            }
                            5 -> {
                                println("Cerrando sesión")
                                break
                            }
                            else -> {
                                println("Opción no válida. Intente nuevamente.")
                            }
                        }
                    }
                } else {
                    println("Inicio de sesión fallido. Verifique su correo y contraseña.")
                }
            }
            2 -> {
                println("Ingrese su nombre:")
                val nombre = readLine().orEmpty()
                println("Ingrese su correo electrónico:")
                val email = readLine().orEmpty()
                println("Ingrese su número de celular:")
                val celular = readLine().orEmpty()
                println("Ingrese su contraseña:")
                val password = readLine().orEmpty()
                println("Confirme su contraseña:")
                val confirmPassword = readLine().orEmpty()
                if (password == confirmPassword) {
                    registroUser(nombre, email, celular, password)
                    println("Registro exitoso.")
                } else {
                    println("Las contraseñas no coinciden. Intente nuevamente.")
                }
            }
            3 -> {
                println("¡Hasta luego!")
                return
            }
            else -> {
                println("Opción no válida. Intente nuevamente.")
            }
        }
    }
}