import java.text.SimpleDateFormat
import java.util.*

class Comparators {
    val prestamosPorPagarQueue: Queue<Prestamo> = PriorityQueue(compareBy { it.fecha })
    val prestamosVencidosQueue: Queue<Prestamo> = PriorityQueue(compareBy { it.fecha })
    val prestamosReportadosQueue: Queue<Prestamo> = PriorityQueue(compareBy { it.fecha })

    class PrestamoPorPagarComparator : Comparator<Prestamo> {
        override fun compare(prestamo1: Prestamo, prestamo2: Prestamo): Int {
            return prestamo1.fecha.compareTo(prestamo2.fecha)
        }
    }

    class PrestamoVencidoComparator : Comparator<Prestamo> {
        override fun compare(prestamo1: Prestamo, prestamo2: Prestamo): Int {
            return prestamo1.fecha.compareTo(prestamo2.fecha)
        }
    }

    class PrestamoReportadoComparator : Comparator<Prestamo> {
        override fun compare(prestamo1: Prestamo, prestamo2: Prestamo): Int {
            val sdf = SimpleDateFormat("yyyy-MM-dd")
            val date1 = sdf.parse(prestamo1.fecha)
            val date2 = sdf.parse(prestamo2.fecha)
            val calendar1 = Calendar.getInstance()
            val calendar2 = Calendar.getInstance()

            calendar1.time = date1
            calendar2.time = date2

            // Comparar por meses
            return calendar1.get(Calendar.MONTH) - calendar2.get(Calendar.MONTH)
        }
        }

        companion object {
            fun mostrarResultados(comparators: Comparators) {
                // Muestra los resultados ordenados por diferentes criterios
                println("Préstamos por pagar:")

                while (comparators.prestamosPorPagarQueue.isNotEmpty()) {
                    val prestamo = comparators.prestamosPorPagarQueue.poll()
                    println("Fecha: ${prestamo.fecha}, Estado: ${prestamo.estado}")
                }

                println("\nPréstamos vencidos:")
                while (comparators.prestamosVencidosQueue.isNotEmpty()) {
                    val prestamo = comparators.prestamosVencidosQueue.poll()
                    println("Fecha: ${prestamo.fecha}, Estado: ${prestamo.estado}")
                }

                println("\nPréstamos reportados:")
                while (comparators.prestamosReportadosQueue.isNotEmpty()) {
                    val prestamo = comparators.prestamosReportadosQueue.poll()
                    println("Fecha: ${prestamo.fecha}, Estado: ${prestamo.estado}")
                }
            }


            fun realizarOperacionesPrestamo(comparators: Comparators) {
                val prestamoDeseado = comparators.prestamosPorPagarQueue.peek()

                if (prestamoDeseado != null) {
                    val estadoActual = prestamoDeseado.obtenerEstadoActual()

                    when (estadoActual) {
                        "Por Pagar" -> comparators.prestamosPorPagarQueue.add(prestamoDeseado)
                        "Vencido" -> comparators.prestamosVencidosQueue.add(prestamoDeseado)
                        "Reportado" -> comparators.prestamosReportadosQueue.add(prestamoDeseado)
                    }
                } else {
                    throw NoSuchElementException("No hay préstamos en la cola.")
                }
            }
        }
    }

