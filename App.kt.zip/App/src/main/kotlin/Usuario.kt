

data class Usuario(val nombre: String, val email: String, val celular: String, val contraseña: String) {

    companion object {
        val registroUsuario = mutableListOf<Usuario>()
        var usuario: Usuario? = null


        fun inicioSesion(email: String, contraseña: String): Boolean {
            val user = registroUsuario.find { it.email == email && it.contraseña == contraseña }
            return user != null
        }

        fun registroUser(nombre: String, email: String, celular: String, password: String) {
            registroUsuario.add(Usuario(nombre, email, celular, password))
        }

        fun datos(user: Usuario) {
            println("Nombre: ${user.nombre}")
            println("Correo: ${user.email}")
            println("Teléfono: ${user.celular}")
        }

        fun editarUsuarioExistente() {
            println("Ingrese su correo para editar sus datos:")
            val email = readLine() ?: ""
            val usuarioExistente = registroUsuario.find { it.email == email }
            if (usuarioExistente != null) {
                println("Ingrese el nuevo nombre:")
                val nuevoNombre = readLine() ?: ""
                println("Ingrese el nuevo correo:")
                val nuevoEmail = readLine() ?: ""
                println("Ingrese el nuevo teléfono:")
                val nuevoCelular = readLine() ?: ""
                println("Ingrese la nueva contraseña:")
                val nuevaContraseña = readLine() ?: ""
                usuarioExistente.editarUsuario(nuevoNombre, nuevoEmail, nuevoCelular, nuevaContraseña)
                println("Usuario actualizado:")
                datos(usuarioExistente)
            } else {
                println("No se encontró un usuario con el correo proporcionado.")
            }
        }

        fun eliminarCuenta(emailAEliminar: String) {
            val usuarioAEliminar = registroUsuario.find { it.email == emailAEliminar }
            if (usuarioAEliminar != null) {
                registroUsuario.remove(usuarioAEliminar)
                usuario = null // Reinicia el usuario actual
                println("Cuenta eliminada. Volviendo al menú principal.")
            } else {
                println("No se encontró una cuenta con el correo proporcionado.")
            }
        }
    }

    private fun editarUsuario(nuevoNombre: String, nuevoEmail: String, nuevoCelular: String, nuevaContraseña: String) {
        var nombre = nuevoNombre
        var email = nuevoEmail
        var celular = nuevoCelular
        var contraseña = nuevaContraseña
    }
}

