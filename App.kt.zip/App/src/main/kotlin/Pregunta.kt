

import java.text.SimpleDateFormat
import java.util.*

data class Pregunta(
        val pregunta: String,
        val fechaP: String
)

class Foro {
    companion object {
        val preguntas = mutableListOf<Pregunta>()

        fun hacerPregunta() {
            println("Ingrese su pregunta:")
            val pregunta = readLine().orEmpty()
            val fechaPregunta = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Date())
            val nuevaPregunta = Pregunta(pregunta, fechaPregunta)
            preguntas.add(nuevaPregunta)
            println("Pregunta realizada con éxito.")
        }

        fun verPreguntas() {
            if (preguntas.isNotEmpty()) {
                println("Preguntas realizadas:")
                for ((index, pregunta) in preguntas.withIndex()) {
                    println("Pregunta ${index + 1}:")
                    println("Pregunta: ${pregunta.pregunta}")
                    println("Fecha: ${pregunta.fechaP}")
                    println("----------------------")
                }
            } else {
                println("No hay preguntas registradas.")
            }
        }
    }
}